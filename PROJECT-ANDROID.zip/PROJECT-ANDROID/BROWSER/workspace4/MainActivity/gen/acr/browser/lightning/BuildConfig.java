/** Automatically generated file. DO NOT MODIFY */
package acr.browser.lightning;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}