This hidden file is there to ensure there is an src folder.
Once we support binary library this will go away.