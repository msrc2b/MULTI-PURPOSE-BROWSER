April 27, 2013

Updated the sample to include two markers, ability to select map type from the actionbar, and saving instance state in order to restore map type, position, and zoom, on device orientation change.

December 18th, 2012

This is an Android project sample implementing the Google Maps Android API v2 sample (https://developers.google.com/maps/documentation/android/).
It's super bare-bones right now, but I hope to keep hacking on it and putting stuff in as I get time.

Note: you must change the API key in the AndroidManifest.xml. Look for "YourKeyGoesHere" and paste your API key there.

The blog post about this:
http://codebybrian.com/2012/12/06/google_maps_android_v2_sample.html

Do anything you want with this code :)


Brian Johnson
codebybrian.com
brian@codebybrian.com
