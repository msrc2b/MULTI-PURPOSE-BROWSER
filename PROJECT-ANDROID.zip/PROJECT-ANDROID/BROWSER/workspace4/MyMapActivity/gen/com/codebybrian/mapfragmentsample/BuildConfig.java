/** Automatically generated file. DO NOT MODIFY */
package com.codebybrian.mapfragmentsample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}