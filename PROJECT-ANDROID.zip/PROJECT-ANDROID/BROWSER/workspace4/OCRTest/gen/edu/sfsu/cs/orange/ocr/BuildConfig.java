/** Automatically generated file. DO NOT MODIFY */
package edu.sfsu.cs.orange.ocr;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}