/** Automatically generated file. DO NOT MODIFY */
package com.googlecode.tesseract.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}